-- delete
--------------------------------------------------------------
--- Must be passable, must not be water
--  Digsites appear on Ruins (2x, First Priority)
--  on Razed Cities (1x, second priority)
--  on Barbarian Camps (2x, third priority)
--  Melee fights, then ranged fights (lesser priority, and we don't want players to go too nuts into combat with the OnuMetru.)


--Use SaveUtils to make this happen. Fire it off whenever a unit moves to save barb camps.
include( "Sukritact_SaveUtils_Onu.lua" ); MY_MOD_NAME = "MetruNui_Matoran_Metrus";

--Initialize
-- for iPlayer = 0, GameDefines.MAX_MAJOR_CIVS - 1, 1 do
	-- local pPlayer = Players[iPlayer]
	-- if pPlayer ~= nil then
		-- if Teams[pPlayer:GetTeam()]:IsHasTech(GameInfoTypes.TECH_ARCHAEOLOGY) then
			-- save(pPlayer, 'ArchDone', 1)
		-- else
			-- save(pPlayer, 'ArchDone', 0)
		-- end
	-- end
-- end

--Every time a OnuMetru moves, save all revealed Ruins and Barbarians.
function OnuMetruRadarPulse(player)
	local pPlayer = Players[player]
	if load(pPlayer, 'ArchDone') == 0 then
		if pPlayer:GetCivilizationType() == GameInfoTypes.CIVILIZATION_ONUMETRU then
			local pTeam = Teams[pPlayer:GetTeam()]
			for plotLoop = Map.GetNumPlots() - 1, 0, -1 do
				local pPlot = Map.GetPlotByIndex(plotLoop)
				if pPlot:IsRevealedGoody(pTeam) then
					save(pPlot, 'Beo', 'G')
				elseif pPlot:IsRevealed(pTeam) and pPlot:GetImprovementType() == GameInfoTypes.IMPROVEMENT_BARBARIAN_CAMP then
					save(pPlot, 'Beo', 'B')
				end
			end
		end
	end
end

function AttemptPlaceSite(x, y, iWeight)
	print("Attempting to Place a Site")
	local range = 3
	local pPlot = Map.GetPlot(x, y)
	local iCrowded = 1
	for dx = -range, range do
		for dy = -range, range do
			local SpecificPlot = Map.PlotXYWithRangeCheck(x, y, dx, dy, range)
			if SpecificPlot ~= nil then
				if SpecificPlot:GetResourceType() == GameInfoTypes.RESOURCE_ARTIFACTS then
					iCrowded = iCrowded + 1
				end
			end
		end
	end
	print(iCrowded .. " sites found here!")
	print(iWeight .. " Salvage Points.")
	local iRand = math.random(100)
	print(iRand)
	if iRand < (iWeight / (iCrowded * iCrowded)) then
		if pPlot:GetResourceType() == -1 then
			pPlot:SetResourceType(GameInfoTypes.RESOURCE_ARTIFACTS, 1)
			print("Site Placed!")
		else
			print("Better luck next time!")
		end
	else
		print("It's way too crowded!")
	end
end

--Every time any unit moves, check to see if he moved onto a Ruin or Barbarian
function GoodyBaddySite(player, unit, x, y)
	local pPlayer = Players[player]
	if load(pPlayer, 'ArchDone') == 0 then
		local pPlot = Map.GetPlot(x, y)
		if load(pPlot, 'Beo') == 'G' then
			print("Goody Site Pillaged!")
			AttemptPlaceSite(x, y, 400)
			save(pPlot, 'Beo', nil)
		elseif load(pPlot, 'Beo') == 'B' then
			print("Barbarian Camp Pillaged!")
			AttemptPlaceSite(x, y, 200)
			save(pPlot, 'Beo', nil)
		end
	end
end

function RazedCitySite(hexpos, player)
	local pPlayer = Player[player]
	local pPlot = Map.GetPlot(hexpos.x, hexpos.y)
	for iPlayer = 0, GameDefines.MAX_MAJOR_CIVS - 1, 1 do
		local pPossibleBeo = Players[iPlayer]
		if pPossibleBeo ~= nil then
			if pPossibleBeo:GetCivilizationType() == GameInfoTypes.CIVILIZATION_ONUMETRU then
				if pPlot:IsRevealed(Teams[pPossibleBeo:GetTeam()]) then --Only counts if they can see it
					print(pPlayer:GetNumTechDifference(pPossibleBeo).." more techs than a OnuMetru")
					if pPlayer:GetNumTechDifference(pPossibleBeo) > 0 then -- Only players with technologies that the OnuMetru don't have need to apply.
						local iWeight = load(pPlot, 'Beo')
						if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
							iWeight = iWeight + 400
						elseif iWeight == nil then
							iWeight = 400
						end
						save(pPlot, 'Beo', iWeight)
						AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
					end
				end
			end
		end
	end
end

function DeadUnitSite(player, iUnit, sUnitType, x, y)
	local pPlayer = Players[player]
	local pPlot = Map.GetPlot(x, y)
	local pUnit = pPlayer:GetUnitByID(iUnit)
	for iPlayer = 0, GameDefines.MAX_MAJOR_CIVS - 1, 1 do
		local pPossibleBeo = Players[iPlayer]
		if pPossibleBeo ~= nil then
			if pPossibleBeo:GetCivilizationType() == GameInfoTypes.CIVILIZATION_ONUMETRU then
				if pPlot:IsRevealed(Teams[pPossibleBeo:GetTeam()]) then --Only counts if they can see it
					if pPlayer:IsBarbarian() then
						if pUnit:IsCanAttackRanged() then
							local iWeight = load(pPlot, 'Beo')
							if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
								iWeight = iWeight + 50
							elseif iWeight == nil then
								iWeight = 50
							end
							save(pPlot, 'Beo', iWeight)
							AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
						else
							local iWeight = load(pPlot, 'Beo')
							if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
								iWeight = iWeight + 40
							elseif iWeight == nil then
								iWeight = 40
							end
							save(pPlot, 'Beo', iWeight)
							AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
						end
					else
						if pPlayer:GetNumTechDifference(pPossibleBeo) > 0 then -- Only players with technologies that the OnuMetru don't have need to apply.
							if pUnit:IsCanAttackRanged() then
								local iWeight = load(pPlot, 'Beo')
								if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
									iWeight = iWeight + 100
								elseif iWeight == nil then
									iWeight = 100
								end
								AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
								save(pPlot, 'Beo', iWeight)
							else
								local iWeight = load(pPlot, 'Beo')
								if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
									iWeight = iWeight + 60
								elseif iWeight == nil then
									iWeight = 60
								end
								save(pPlot, 'Beo', iWeight)
								AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
							end
						else
							if pUnit:IsCanAttackRanged() then
								local iWeight = load(pPlot, 'Beo')
								if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
									iWeight = iWeight + 50
								elseif iWeight == nil then
									iWeight = 50
								end
								save(pPlot, 'Beo', iWeight)
								AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
							else
								local iWeight = load(pPlot, 'Beo')
								if iWeight ~= 'G' and iWeight ~= 'B' and iWeight ~= nil then
									iWeight = iWeight + 40
								elseif iWeight == nil then
									iWeight = 40
								end
								save(pPlot, 'Beo', iWeight)
								AttemptPlaceSite(hexpos.x, hexpos.y, iWeight)
							end
						end
					end
				end
			end
		end
	end
end

local iOnuMetruCiv = GameInfoTypes.CIVILIZATION_ONUMETRU
local iOnuMetruTraitDummyBuilding = GameInfoTypes.BUILDING_ONUMETRUTRAIT
function OnuMetruTraitEnforce(iPlayer,x,y)
	local pPlayer = Players[iPlayer]
	if pPlayer:GetCivilizationType() == iOnuMetruCiv then
		local pPlot = Map.GetPlot(x, y)
		local pCity = pPlot:GetPlotCity()
		if pCity:GetNumRealBuilding(iOnuMetruTraitDummyBuilding) ~= 0 then
			-- pCity:SetNumRealBuilding(iOnuMetruTraitDummyBuilding, 1)
			print(pCity:GetName(),"has dummy building ")
		end
	end
end

for i = 0, GameDefines.MAX_MAJOR_CIVS - 1, 1 do
	local pPlayer = Players[i]
	if pPlayer:IsEverAlive() and pPlayer:GetCivilizationType() == GameInfoTypes.CIVILIZATION_ONUMETRU then
		-- print("OnuMetru Trait lua loaded!")
		-- GameEvents.UnitPrekill.Add(DeadUnitSite)  
		-- Events.SerialEventCityDestroyed.Add(RazedCitySite)
		-- GameEvents.UnitSetXY.Add(GoodyBaddySite)
		-- GameEvents.UnitSetXY.Add(OnuMetruRadarPulse)
		-- GameEvents.PlayerCityFounded.Add(OnuMetruTraitEnforce)
		break
    end
end