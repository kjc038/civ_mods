-- WallBuild
-- Author: IlMatteo
-- DateCreated: 7/26/2015 10:01:04 AM
--------------------------------------------------------------
local wallID = GameInfoTypes["IMPROVEMENT_WALL"];
--------------------------------------------------------------------
Events.SerialEventEraChanged.Add(
function(arg, iPlayer)
	print("ERA");
	print(Players[iPlayer]:GetCurrentEra());
	if (Players[iPlayer]:GetCurrentEra() == 3) then
		for pUnit in Players[iPlayer]:Units() do
			if (pUnit:GetUnitType() == GameInfo.Units.UNIT_VALRUM.ID) then
				pUnit:Kill(false, nil);
			end
		end
	end
end)
-------------------------------------------------------------------
function OnUpdateWall(playerID, x, y, improvementID)
	if (improvementID ~= wallID) then return end
	MakeMountain(Map.GetPlot(x, y));
end
--------------------------------------------------------------------
function OnMapUpdateWall()
	local n = Map.GetNumPlots() - 1;
	for i = 0, n do
		local plot = Map.GetPlotByIndex(i);
		if (plot:GetImprovementType() == wallID) then
			MakeMountain(plot);
		end
	end
end
--------------------------------------------------------------------
function OnTechResearched(teamID, techID)
	if forestTechInfo and (techID == forestTechInfo.ID) then
		Events.ActivePlayerTurnStart.Add(OnMapUpdateForests);
		GameEvents.TeamTechResearched.Remove(OnTechResearched);
	end
end
--------------------------------------------------------------------
function MakeMountain(plot)
	plot:SetImprovementType(-1);
	plot:SetPlotType(PlotTypes.PLOT_MOUNTAIN, true, true);
	if (Map.GetPlot(plot:GetUnit(0):GetX()+1, plot:GetUnit(0):GetY()):GetPlotType() ~= PlotTypes.PLOT_MOUNTAIN) then
		plot:GetUnit(0):SetXY(plot:GetUnit(0):GetX()+1, plot:GetUnit(0):GetY(), 0, 1, 0, 0);
	elseif (Map.GetPlot(plot:GetUnit(0):GetX()-1, plot:GetUnit(0):GetY()):GetPlotType() ~= PlotTypes.PLOT_MOUNTAIN) then
		plot:GetUnit(0):SetXY(plot:GetUnit(0):GetX()-1, plot:GetUnit(0):GetY(), 0, 1, 0, 0);
	elseif (Map.GetPlot(plot:GetUnit(0):GetX(), plot:GetUnit(0):GetY()+1):GetPlotType() ~= PlotTypes.PLOT_MOUNTAIN) then
		plot:GetUnit(0):SetXY(plot:GetUnit(0):GetX(), plot:GetUnit(0):GetY()+1, 0, 1, 0, 0);
	elseif (Map.GetPlot(plot:GetUnit(0):GetX(), plot:GetUnit(0):GetY()+1):GetPlotType() == PlotTypes.PLOT_MOUNTAIN) then
		plot:GetUnit(0):SetXY(plot:GetUnit(0):GetX(), plot:GetUnit(0):GetY()-1, 0, 1, 0, 0);
	end
end
--------------------------------------------------------------------
function Initialize()
	GameEvents.BuildFinished.Add(OnUpdateWall);
end
--------------------------------------------------------------------
Initialize();