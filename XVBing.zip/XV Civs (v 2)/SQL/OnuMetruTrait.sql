--==========================================================================================================================	
-- BuildingClasses
--==========================================================================================================================	

INSERT INTO BuildingClasses 
			(DefaultBuilding, 					Type, 									Description)
VALUES		('BUILDING_ONUMETRUTRAIT', 		'BUILDINGCLASS_ONUMETRUTRAIT', 		'TXT_KEY_BUILDING_ONUMETRUTRAIT');
--==========================================================================================================================	

--==========================================================================================================================	
INSERT INTO Buildings 
			(Type, 								BuildingClass, 						GreatWorkCount,	Cost, 	FaithCost,	GoldMaintenance, PrereqTech,			NeverCapture,	Description, 							Help,NukeImmune)
VALUES		('BUILDING_ONUMETRUTRAIT', 		'BUILDINGCLASS_ONUMETRUTRAIT',		-1,				-1, 	-1,			0,				 NULL,	1,				'TXT_KEY_BUILDING_ONUMETRUTRAIT',		'TXT_KEY_BUILDING_ONUMETRUTRAIT_HELP',1);
--==========================================================================================================================	
-- Traits
--==========================================================================================================================	
INSERT INTO Traits 
			(Type,								FreeBuilding)
VALUES		('TRAIT_ONUMETRU',			'BUILDING_ONUMETRUTRAIT');	

INSERT INTO Policies (Type,Level)
SELECT 'POLICY_ONUMETRU_REVEAL_HIDDEN_ARTIFACTS',(SELECT ID FROM PolicyBranchTypes WHERE FreeFinishingPolicy IS (SELECT PolicyReveal FROM Resources WHERE Type IS 'RESOURCE_HIDDEN_ARTIFACTS'));

UPDATE Resources 
SET PolicyReveal = 'POLICY_ONUMETRU_REVEAL_HIDDEN_ARTIFACTS'
WHERE Type IS 'RESOURCE_HIDDEN_ARTIFACTS';

INSERT INTO Technologies (Type, Cost, Disable, Description, Civilopedia, Help, Era, GridX, GridY, PortraitIndex, IconAtlas,TriggersArchaeologicalSites)
VALUES ('TECH_ARCHTECHFIX', -1, 1, 'TXT_KEY_TRAIT_ONUMETRU', 'TXT_KEY_TRAIT_ONUMETRU',	'', 'ERA_ANCIENT',	0, -12, 43, 'TECH_ATLAS_1',1);

UPDATE Resources
SET TechReveal = 'TECH_ARCHTECHFIX'
WHERE Type = 'RESOURCE_ARTIFACTS';

UPDATE Technologies
SET TriggersArchaeologicalSites = 0
WHERE Type = 'TECH_ARCHAEOLOGY';

--==========================================================================================================================	
-- Language_en_US
--==========================================================================================================================	
INSERT INTO Language_en_US
			(Tag,										Text)
VALUES		('TXT_KEY_TRAIT_ONUMETRU',					'See regular and Hidden Antiquity [ICON_RES_HIDDEN_ARTIFACTS] sites from the ancient era. Scientist specialists yield +1 [ICON_CULTURE]'),
			('TXT_KEY_TRAIT_ONUMETRU_SHORT',			'The Great Archives'),
			('TXT_KEY_BUILDING_ONUMETRUTRAIT',			'The Great Archives'),
			('TXT_KEY_BUILDING_ONUMETRUTRAIT_HELP',		'Contact FieryCharizard7 if you see this');


ALTER TABLE Technologies ADD ShowInPedia INTEGER DEFAULT 1;

UPDATE Technologies
SET ShowInPedia = 0
WHERE Type = 'TECH_ARCHTECHFIX';