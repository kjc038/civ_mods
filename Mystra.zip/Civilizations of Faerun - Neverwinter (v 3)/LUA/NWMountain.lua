-- NWMountain
-- Author: Marryth
-- DateCreated: 10/15/2017 12:27:09 AM
--------------------------------------------------------------
Events.SequenceGameInitComplete.Add(function()
	for i = 0, Map:GetNumPlots() - 1, 1 do
		local fPlot = Map.GetPlotByIndex( i );
		if fPlot:IsMountain() then
			if fPlot:GetFeatureType() == -1  then
				fPlot:SetFeatureType(GameInfoTypes.FEATURE_NEVERWINTER_MOUNTAIN,-1);
			end
		end
	end
end)